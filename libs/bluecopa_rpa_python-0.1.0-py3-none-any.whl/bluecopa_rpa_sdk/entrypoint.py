import os
from abc import ABC
from bluecopa_rpa_sdk.utils.robot_protocol import RobotStateMessage, RobotMessage, Type
from bluecopa_rpa_sdk.robots.abstract_robot import AbstractRobot
from bluecopa_rpa_sdk.utils.robot_logging import init_logger
from bluecopa_rpa_sdk.utils.robot_secrets_utils import get_secrets, update_secrets, split_config
from typing import List, Iterable, Mapping, Any, Union, MutableMapping
import logging
import argparse
import tempfile
from bluecopa_rpa_sdk.utils.robot_protocol import RobotSpecification, FailureType
from bluecopa_rpa_sdk.utils.robot_exceptions import RobotTracedException
from jsonschema import validate
from jsonschema.exceptions import ValidationError
import base64

logger = init_logger("robot-wf")
ENV_REQUEST_CACHE_PATH = "REQUEST_CACHE_PATH"


def _set_nested_key(d, keys, value):
    for key in keys[:-1]:
        if key not in d or not isinstance(d[key], dict):
            d[key] = {}
        d = d[key]
    d[keys[-1]] = value


class RobotEntryPoint(ABC):

    def __init__(self, source: AbstractRobot):
        self.source = source
        self.logger = logging.getLogger(f"Robot.{getattr(source, 'name', '')}")

    __input_file_path: str = None
    __output_file_path: str = None
    __state_file_path: str = None
    __config: dict = {}
    __state: dict = {}
    __output: dict = {}

    @staticmethod
    def parse_args(args: List[str]) -> argparse.Namespace:
        # set up parent parsers
        parent_parser = argparse.ArgumentParser(add_help=False)
        parent_parser.add_argument("--debug", action="store_true",
                                   help="enables detailed debug logs related to the sync")
        main_parser = argparse.ArgumentParser()
        subparsers = main_parser.add_subparsers(title="commands", dest="command")

        # spec
        subparsers.add_parser("spec", help="outputs the json configuration specification", parents=[parent_parser])

        # # check
        # check_parser = subparsers.add_parser("check", help="checks the config can be used to connect",
        #                                      parents=[parent_parser])
        # required_check_parser = check_parser.add_argument_group("required named arguments")
        # required_check_parser.add_argument("--config", type=str, required=True,
        #                                    help="path to the json configuration file")

        # run
        run_parser = subparsers.add_parser("run", help="runs the robot and outputs messages to STDOUT",
                                           parents=[parent_parser])

        run_parser.add_argument("--state", type=str, required=False, help="path to the json-encoded state file")
        required_read_parser = run_parser.add_argument_group("required named arguments")
        required_read_parser.add_argument("--config", type=str, required=True,
                                          help="path to the config file")
        required_read_parser.add_argument("--input-file-path", type=str, required=True,
                                          help="path to the input file")
        required_read_parser.add_argument(
            "--output-folder-path", type=str, required=False, help="path to the output folder"
        )

        return main_parser.parse_args(args)

    def __init(self, inputs):
        self.__input_file_path = inputs["input_file_path"]
        self.__output_file_path = inputs["output_file_path"]
        self.__config = inputs["config"]
        self.__state_file_path = inputs["state_file_path"]

    def update_state(self, key_or_state, value=None):
        if isinstance(key_or_state, dict):
            self.__state = key_or_state
        elif isinstance(key_or_state, str):
            keys = key_or_state.split(".")
            _set_nested_key(self.__state, keys, value)
        else:
            raise TypeError("Invalid argument type for update_state")

    def update_output(self, key_or_output, value=None):
        if isinstance(key_or_output, dict):
            self.__output = key_or_output
        elif isinstance(key_or_output, str):
            keys = key_or_output.split(".")
            _set_nested_key(self.__output, keys, value)
        else:
            raise TypeError("Invalid argument type for update_output")

    def run(self, parsed_args: argparse.Namespace) -> Iterable[str]:
        cmd = parsed_args.command
        if not cmd:
            raise Exception("No command passed")

        if hasattr(parsed_args, "debug") and parsed_args.debug:
            self.logger.setLevel(logging.DEBUG)
            logger.setLevel(logging.DEBUG)
            self.logger.debug("Debug logs enabled")
        else:
            self.logger.setLevel(logging.INFO)

        source_spec: RobotSpecification = self.source.spec(self.logger)

        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                os.environ[
                    ENV_REQUEST_CACHE_PATH] = temp_dir  # set this as default directory for request_cache to store *.sqlite files
                if cmd == "spec":
                    message = RobotMessage(type=Type.SPEC, spec=source_spec)
                    yield from [
                        self.robot_message_to_string(queued_message) for queued_message in
                        self._emit_queued_messages(self.source)
                    ]
                    yield self.robot_message_to_string(message)
                else:
                    raw_config = self.source.read_config(parsed_args.config)
                    config = self.source.configure(raw_config, temp_dir)

                    if cmd == "run":
                        state = self.source.read_state(parsed_args.state)
                        print("input_file_path as argument", parsed_args.input_file_path)
                        input_file_path = self.get_input_file_name(parsed_args.input_file_path)
                        output_folder_path = parsed_args.output_folder_path
                        if output_folder_path is None:
                            dir_name, base_name = os.path.split(input_file_path)
                            output_folder_path = dir_name + "/outputs"
                            if not os.path.exists(output_folder_path):
                                # Create the directory (and any intermediate directories)
                                os.makedirs(output_folder_path)
                        yield from map(RobotEntryPoint.robot_message_to_string,
                                       self.run_robot(source_spec, config, input_file_path, output_folder_path, state))
                        self.source.update_state(state, parsed_args.state)

                    else:
                        raise Exception("Unexpected command " + cmd)

        finally:
            yield from [self.robot_message_to_string(queued_message) for queued_message in
                        self._emit_queued_messages(self.source)]

    def get_input_file_name(self, input_file_path):
        if self.is_base64_encoded(input_file_path):
            decoded_bytes = base64.b64decode(input_file_path)
            return decoded_bytes.decode('utf-8')
        else:
            return input_file_path

    @staticmethod
    def is_base64_encoded(input_file_path):
        try:
            # Try to decode the string
            decoded = base64.b64decode(input_file_path, validate=True)
            return base64.b64encode(decoded).decode('utf-8') == input_file_path
        except Exception:
            return False

    @staticmethod
    def robot_message_to_string(robot_message: RobotMessage) -> str:
        return robot_message.json(exclude_unset=True)

    @staticmethod
    def _emit_queued_messages(source) -> Iterable[RobotMessage]:
        if hasattr(source, "message_repository") and source.message_repository:
            yield from source.message_repository.consume_queue()
        return

    def run_robot(self, robot_spec: RobotSpecification, config: Mapping[str, Any], input_file_path: str, output_folder_path: str,
                  state: Union[List[RobotStateMessage], MutableMapping[str, Any]]):
        self.set_up_secret_filter(config, robot_spec.robotSpecification)
        if self.source.check_config_against_spec:
            self.validate_connection(robot_spec, config)

        self.source.run_robot(self.logger, config, input_file_path, output_folder_path, state)
        yield from self._emit_queued_messages(self.source)

    @staticmethod
    def set_up_secret_filter(config, robot_specification: Mapping[str, Any]):
        # Now that we have the config, we can use it to get a list of ai airbyte_secrets
        # that we should filter in logging to avoid leaking secrets
        config_secrets = get_secrets(robot_specification, config)
        update_secrets(config_secrets)

    @staticmethod
    def validate_connection(robot_spec: RobotSpecification, config: Mapping[str, Any]) -> None:
        # Remove internal flags from config before validating so
        # jsonschema's additionalProperties flag won't fail the validation
        connector_config, _ = split_config(config)
        check_config_against_spec_or_exit(connector_config, robot_spec)


def launch(source: AbstractRobot, args: List[str]):
    source_entrypoint = RobotEntryPoint(source)
    parsed_args = source_entrypoint.parse_args(args)
    for message in source_entrypoint.run(parsed_args):
        print(message)

def check_config_against_spec_or_exit(config: Mapping[str, Any], spec: RobotSpecification):
    """
    Check config object against spec. In case of spec is invalid, throws
    an exception with validation error description.

    :param config - config loaded from file specified over command line
    :param spec - spec object generated by connector
    """
    spec_schema = spec.robotSpecification
    try:
        validate(instance=config, schema=spec_schema)
    except ValidationError as validation_error:
        raise RobotTracedException(
            message="Config validation error: " + validation_error.message,
            internal_message=validation_error.message,
            failure_type=FailureType.config_error,
        ) from None  # required to prevent logging config secrets from the ValidationError's stacktrace

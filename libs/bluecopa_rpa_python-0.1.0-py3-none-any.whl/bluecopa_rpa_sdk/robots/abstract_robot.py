from abc import ABC, abstractmethod
import json
import os
import yaml
import logging
import pkgutil
from typing import Optional, Union, Callable, Iterable, Mapping, Any, List, Protocol, MutableMapping, TypeVar
from bluecopa_rpa_sdk.utils.robot_protocol import RobotSpecification, RobotMessage, Level, RobotStateMessage

JsonType = Union[dict[str, "JsonType"], list["JsonType"], str, int, float, bool, None]
LogMessage = dict[str, JsonType]

def load_optional_package_file(package: str, filename: str) -> Optional[bytes]:
    """Gets a resource from a package, returning None if it does not exist"""
    try:
        return pkgutil.get_data(package, filename)
    except FileNotFoundError:
        return None

def _read_json_file(file_path: str) -> Union[None, bool, float, int, str, List[Any], Mapping[str, Any]]:
    with open(file_path, "r") as file:
        contents = file.read()

    try:
        return json.loads(contents)
    except json.JSONDecodeError as error:
        raise ValueError(f"Could not read json file {file_path}: {error}. Please ensure that it is a valid JSON.")


class MessageRepository(ABC):
    @abstractmethod
    def emit_message(self, message: RobotMessage) -> None:
        raise NotImplementedError()

    @abstractmethod
    def log_message(self, level: Level, message_provider: Callable[[], LogMessage]) -> None:
        """
        Computing messages can be resource consuming. This method is specialized for logging because we want to allow for lazy evaluation if
        the log level is less severe than what is configured
        """
        raise NotImplementedError()

    @abstractmethod
    def consume_queue(self) -> Iterable[RobotMessage]:
        raise NotImplementedError()


class _WriteConfigProtocol(Protocol):
    @staticmethod
    def write_config(config: Mapping[str, Any], config_path: str):
        ...


class AbstractRobot(
    ABC,
):
    # configure whether the `check_config_against_spec_or_exit()` needs to be called
    check_config_against_spec: bool = True

    @property
    def name(self) -> str:
        """Source name"""
        return self.__class__.__name__

    def spec(self, logger: logging.Logger) -> RobotSpecification:
        """
        Returns the spec for this integration. The spec is a JSON-Schema object describing the required configurations (e.g: username and password)
        required to run this integration. By default, this will be loaded from a "spec.yaml" or a "spec.json" in the package root.
        """

        package = self.__class__.__module__.split(".")[0]

        yaml_spec = load_optional_package_file(package, "spec.yaml")
        json_spec = load_optional_package_file(package, "spec.json")

        if yaml_spec and json_spec:
            raise RuntimeError("Found multiple spec files in the package. Only one of spec.yaml or spec.json should be provided.")

        if yaml_spec:
            spec_obj = yaml.load(yaml_spec, Loader=yaml.SafeLoader)
        elif json_spec:
            try:
                spec_obj = json.loads(json_spec)
            except json.JSONDecodeError as error:
                raise ValueError(f"Could not read json spec file: {error}. Please ensure that it is a valid JSON.")
        else:
            raise FileNotFoundError("Unable to find spec.yaml or spec.json in the package.")

        return RobotSpecification.parse_obj(spec_obj)

    @staticmethod
    def read_config(config_path: str) -> Mapping[str, Any]:
        config = _read_json_file(config_path)
        if isinstance(config, Mapping):
            return config
        else:
            raise ValueError(
                f"The content of {config_path} is not an object and therefore is not a valid config. Please ensure the file represent a config."
            )

    def configure(self: _WriteConfigProtocol, config: Mapping[str, Any], temp_dir: str) -> Mapping[str, Any]:
        config_path = os.path.join(temp_dir, "config.json")
        # self.write_config(config, config_path)
        return config


    @property
    def message_repository(self) -> Union[None, MessageRepository]:
        return None

    def read_state(self, state_path: str) -> Union[List[RobotStateMessage], MutableMapping[str, Any]]:
        """
        Retrieves the input state of a sync by reading from the specified JSON file. Incoming state can be deserialized into either
        a JSON object for legacy state input or as a list of RobotStateMessages for the per-stream state format. Regardless of the
        incoming input type, it will always be transformed and output as a list of RobotStateMessage(s).
        :param state_path: The filepath to where the stream states are located
        :return: The complete stream state based on the connector's previous sync
        """
        if state_path:
            state_obj = self._read_json_file(state_path)
            if not state_obj:
                return {}
            else:
                return state_obj
        return {}

    @staticmethod
    def _read_json_file(file_path: str) -> Union[None, bool, float, int, str, List[Any], Mapping[str, Any]]:
        if os.path.exists(file_path):
            with open(file_path, "r") as file:
                contents = file.read()
            try:
                return json.loads(contents)
            except json.JSONDecodeError as error:
                raise ValueError(
                    f"Could not read json file {file_path}: {error}. Please ensure that it is a valid JSON.")
        else:
            return {}

    def update_state(self, state: Union[List[RobotStateMessage], MutableMapping[str, Any]], state_file_path: str):
        # override this method to implement state safe
        if state_file_path:
            new_state = state
            self.write_state_file(new_state, state_file_path)

    @staticmethod
    def write_state_file(state: Union[List[RobotStateMessage], MutableMapping[str, Any]], state_file_path: str):
        if state_file_path:
            try:
                with open(state_file_path, 'w') as state_file:
                    json.dump(state, state_file, indent=4)
            except IOError as e:
                print(f"Error writing state file: {e}")

    @abstractmethod
    def run_robot(self, logger: logging.Logger, config: Mapping[str, Any], input_file_path: str, output_folder_path: str, state: Union[List[RobotStateMessage], MutableMapping[str, Any]] = None):
        # override this method to run the robot
        pass


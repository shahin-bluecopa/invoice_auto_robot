from __future__ import annotations
from enum import Enum
from pydantic import AnyUrl, BaseModel, Extra, Field
from typing import Any, Dict, List, Optional


class Type(Enum):
    RECORD = 'RECORD'
    STATE = 'STATE'
    LOG = 'LOG'
    SPEC = 'SPEC'
    SPEC_STATUS = 'SPEC_STATUS'
    CATALOG = 'CATALOG'
    TRACE = 'TRACE'
    CONTROL = 'CONTROL'


class Level(Enum):
    FATAL = 'FATAL'
    ERROR = 'ERROR'
    WARN = 'WARN'
    INFO = 'INFO'
    DEBUG = 'DEBUG'
    TRACE = 'TRACE'


class RobotStateType(Enum):
    GLOBAL = 'GLOBAL'
    STREAM = 'STREAM'
    LEGACY = 'LEGACY'


class TraceType(Enum):
    ERROR = 'ERROR'
    ESTIMATE = 'ESTIMATE'
    STREAM_STATUS = 'STREAM_STATUS'


class FailureType(Enum):
    system_error = 'system_error'
    config_error = 'config_error'


class EstimateType(Enum):
    STREAM = 'STREAM'
    SYNC = 'SYNC'


class RobotStreamStatus(Enum):
    STARTED = 'STARTED'
    RUNNING = 'RUNNING'
    COMPLETE = 'COMPLETE'
    INCOMPLETE = 'INCOMPLETE'


class OrchestratorType(Enum):
    CONNECTOR_CONFIG = 'CONNECTOR_CONFIG'


class StreamDescriptor(BaseModel):
    class Config:
        extra = Extra.allow

    name: str
    namespace: Optional[str] = None


class RobotStateBlob(BaseModel):
    pass

    class Config:
        extra = Extra.allow


class RobotStreamState(BaseModel):
    class Config:
        extra = Extra.allow

    stream_descriptor: StreamDescriptor
    stream_state: Optional[RobotStateBlob] = None


class RobotLogMessage(BaseModel):
    class Config:
        extra = Extra.allow

    level: Level = Field(..., description='log level')
    message: str = Field(..., description='log message')
    stack_trace: Optional[str] = Field(
        None,
        description='an optional stack trace if the log message corresponds to an exception',
    )


class RobotRecordMessage(BaseModel):
    class Config:
        extra = Extra.allow

    namespace: Optional[str] = Field(
        None, description='namespace the data is associated with'
    )
    stream: str = Field(..., description='stream the data is associated with')
    data: Dict[str, Any] = Field(..., description='record data')
    emitted_at: int = Field(
        ...,
        description='when the data was emitted from the source. epoch in millisecond.',
    )


class RobotGlobalState(BaseModel):
    class Config:
        extra = Extra.allow

    shared_state: Optional[RobotStateBlob] = None
    stream_states: List[RobotStreamState]


class RobotStateMessage(BaseModel):
    class Config:
        extra = Extra.allow

    type: Optional[RobotStateType] = None
    stream: Optional[RobotStreamState] = None
    global_: Optional[RobotGlobalState] = Field(None, alias='global')
    data: Optional[Dict[str, Any]] = Field(
        None, description='the state data'
    )


class RobotErrorTraceMessage(BaseModel):
    class Config:
        extra = Extra.allow

    message: str = Field(
        ..., description='A user-friendly message that indicates the cause of the error'
    )
    internal_message: Optional[str] = Field(
        None, description='The internal error that caused the failure'
    )
    stack_trace: Optional[str] = Field(
        None, description='The full stack trace of the error'
    )
    failure_type: Optional[FailureType] = Field(None, description='The type of error')
    stream_descriptor: Optional[StreamDescriptor] = Field(
        None, description='The stream associated with the error, if known (optional)'
    )


class RobotEstimateTraceMessage(BaseModel):
    class Config:
        extra = Extra.allow

    name: str = Field(..., description='The name of the stream')
    type: EstimateType = Field(
        ...,
        description='Estimates are either per-stream (STREAM) or for the entire sync (SYNC). STREAM is preferred, and requires the source to count how many records are about to be emitted per-stream (e.g. there will be 100 rows from this table emitted). For the rare source which cannot tell which stream a record belongs to before reading (e.g. CDC databases), SYNC estimates can be emitted. Sources should not emit both STREAM and SOURCE estimates within a sync.\n',
        title='estimate type',
    )
    namespace: Optional[str] = Field(None, description='The namespace of the stream')
    row_estimate: Optional[int] = Field(
        None,
        description='The estimated number of rows to be emitted by this sync for this stream',
    )
    byte_estimate: Optional[int] = Field(
        None,
        description='The estimated number of bytes to be emitted by this sync for this stream',
    )


class RobotStreamStatusTraceMessage(BaseModel):
    class Config:
        extra = Extra.allow

    stream_descriptor: StreamDescriptor = Field(
        ..., description='The stream associated with the status'
    )
    status: RobotStreamStatus = Field(
        ..., description='The current status of the stream'
    )


class RobotTraceMessage(BaseModel):
    class Config:
        extra = Extra.allow

    type: TraceType = Field(
        ..., description='the type of trace message', title='trace type'
    )
    emitted_at: float = Field(
        ..., description='the time in ms that the message was emitted'
    )
    error: Optional[RobotErrorTraceMessage] = Field(
        None, description='error trace message: the error object'
    )
    estimate: Optional[RobotEstimateTraceMessage] = Field(
        None,
        description='Estimate trace message: a guess at how much data will be produced in this sync',
    )
    stream_status: Optional[RobotStreamStatusTraceMessage] = Field(
        None,
        description='Stream status trace message:  the current status of a stream within a source',
    )


class RobotControlConnectorConfigMessage(BaseModel):
    class Config:
        extra = Extra.allow

    config: Dict[str, Any] = Field(
        ..., description="the config items from this connector's spec to update"
    )


class RobotControlMessage(BaseModel):
    class Config:
        extra = Extra.allow

    type: OrchestratorType = Field(
        ..., description='the type of orchestrator message', title='orchestrator type'
    )
    emitted_at: float = Field(
        ..., description='the time in ms that the message was emitted'
    )
    connectorConfig: Optional[RobotControlConnectorConfigMessage] = Field(
        None,
        description='connector config orchestrator message: the updated config for the platform to store for this connector',
    )


class RobotSpecification(BaseModel):
    class Config:
        extra = Extra.allow

    documentationUrl: Optional[AnyUrl] = None
    changelogUrl: Optional[AnyUrl] = None
    robotSpecification: Dict[str, Any] = Field(
        ...,
        description='RobotDefinition specific blob. Must be a valid JSON string.',
    )


class RobotMessage(BaseModel):
    class Config:
        extra = Extra.allow

    type: Type = Field(..., description='Message type')
    log: Optional[RobotLogMessage] = Field(
        None,
        description='log message: any kind of logging you want the platform to know about.',
    )
    spec: Optional[RobotSpecification] = None
    specStatus: Optional[RobotSpecStatus] = None
    record: Optional[RobotRecordMessage] = Field(
        None, description='record message: the record'
    )
    state: Optional[RobotStateMessage] = Field(
        None,
        description='schema message: the state. Must be the last message produced. The platform uses this information',
    )
    trace: Optional[RobotTraceMessage] = Field(
        None,
        description='trace message: a message to communicate information about the status and performance of a connector',
    )
    control: Optional[RobotControlMessage] = Field(
        None,
        description='connector config message: a message to communicate an updated configuration from a connector that should be persisted',
    )

class Status(Enum):
    SUCCEEDED = 'SUCCEEDED'
    FAILED = 'FAILED'


class RobotSpecStatus(BaseModel):
    class Config:
        extra = Extra.allow

    status: Status
    message: Optional[str] = None